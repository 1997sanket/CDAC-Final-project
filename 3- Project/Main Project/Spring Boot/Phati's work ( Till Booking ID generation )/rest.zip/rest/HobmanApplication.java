package com.hobman.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HobmanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HobmanApplication.class, args);
	}

}
