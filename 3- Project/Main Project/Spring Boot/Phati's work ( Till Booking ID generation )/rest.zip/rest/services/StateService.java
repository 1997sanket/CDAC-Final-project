package com.hobman.rest.services;
import java.util.List;
import com.hobman.rest.models.State;

public interface StateService {
	
	public List<State> getStates();

}
